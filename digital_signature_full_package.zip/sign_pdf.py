# sign placeholder
print('Sign placeholder')