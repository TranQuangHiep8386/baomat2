# verify placeholder
print('Verify placeholder')